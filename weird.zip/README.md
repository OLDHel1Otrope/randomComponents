## Targets

- [] **fixing the grid rerendering bug** 
- [] **fixing type errors** 
- [] **making the yaml file for hosting this in aws** 
- [] **creating api to display the projects, rather than hard coding them** 
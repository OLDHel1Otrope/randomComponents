// import { useBox } from "@react-three/cannon";
// import * as THREE from "three";

// export function RaceTrack() {
//   const [ref] = useBox(() => ({
//     args: [50, 1, 50], // Width, Height, Depth
//     position: [0, -0.5, 0],
//     type: "Static",
//   }));

//   return (
//     <mesh ref={ref} receiveShadow>
//       <boxGeometry args={[50, 1, 50]} />
//       <meshStandardMaterial color="green" roughness={0.8} metalness={0.2} />
//     </mesh>
//   );
// }

import KeyboardGenerator from "@/components/KeyboardGenerator";

const x = () => {
  return (
    <div className="p-4 bg-stone-950 flex flex-col gap-1 items-center  rounded-lg ">
      <KeyboardGenerator />
    </div>
  );
};
export default x;